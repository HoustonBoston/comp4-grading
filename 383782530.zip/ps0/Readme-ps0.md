# PS0: Hello SFML

## Contact
Name: Joshua MacNeill 

Section: 201

Time to Complete: ~1.5 hours


## Description
the project has a moveable sprite that moves in a direction WASD format. There is also the final countdown playing
in the background as music

### Features
I decided to make the sprite move with keystrokes because i wanted it to be like a video game, i chose the final countdown as the music because i thought it would be funny
### Extra Feature
Describe anything special you did.  This is required to earn points.

### Issues
What doesn't work.  Be honest.  You might be penalized if you claim something works and it doesn't.


## Integrity
Read the University policy Academic Integrity, and answer the following question:

There are nine examples of academic misconduct, labeled (1) through (9). Other than (1), "Seeks to claim credit for the work or efforts of another without authorization or citation," which of these do you think would most apply to this class, and why? Write approx. 100-200 words. Note: there is no single correct answer to this. I am looking for your opinion.

I would say #9 because in the computer science field in general "vibe coders" or people who use a.i to code for them. Computer science tests your problem solving and is a practical skill that needs consistent use/practice to actually improve. if you have A.I do all the work for you then at that point you arent learning the necessary skills to be a good programmer. Even if you understand the concepts behind the genreated code you stil arent improving because you need to have hands on experience to code smoothly and withoyt errors, having a.i do the syntax and problem solving is just detrimental to your future experience as a programmer.


## Acknowledgements
List all sources of help including the instructor or TAs, classmates, and web pages.

### Credits
final countdown : https://www.soundboard.com/sb/sound/916334#google_vignette
heart sprite : https://www.pixilart.com/draw/undertale-soul-365a25e35b530d1
