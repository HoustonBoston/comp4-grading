// Copyright 2026 Joshua MacNeill
#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

int main() {
    sf::RenderWindow window(sf::VideoMode({1280, 720}), "SFML works!");
    sf::CircleShape cursor(15.f);
    cursor.setFillColor(sf::Color::Red);
    sf::Texture soul("sprite.png");
    sf::Sprite soul_sprite(soul);
    sf::Music music;
    if (music.openFromFile("final_countdown.ogg")) {
        music.play();
    }
    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            // if w is pressed
            if (event->is<sf::Event::KeyPressed>()) {
                if (event->getIf<sf::Event::KeyPressed>()->code ==
                    sf::Keyboard::Key::W) {
                    sf::Vector2f pos = soul_sprite.getPosition();
                    pos.y -= 10.0f;
                    soul_sprite.setPosition(pos);
                }
            }
            // if s is pressed
            if (event->is<sf::Event::KeyPressed>()) {
                if (event->getIf<sf::Event::KeyPressed>()->code ==
                    sf::Keyboard::Key::S) {
                    sf::Vector2f pos = soul_sprite.getPosition();
                    pos.y += 10.0f;
                    soul_sprite.setPosition(pos);
                }
            }
            // if A is pressed
            if (event->is<sf::Event::KeyPressed>()) {
                if (event->getIf<sf::Event::KeyPressed>()->code ==
                    sf::Keyboard::Key::A) {
                    sf::Vector2f pos = soul_sprite.getPosition();
                    pos.x -= 10.0f;
                    soul_sprite.setPosition(pos);
                }
            }
            // if D is pressed
            if (event->is<sf::Event::KeyPressed>()) {
                if (event->getIf<sf::Event::KeyPressed>()->code ==
                    sf::Keyboard::Key::D) {
                    sf::Vector2f pos = soul_sprite.getPosition();
                    pos.x += 10.0f;
                    soul_sprite.setPosition(pos);
                }
            }
            if (event->is<sf::Event::Closed>())
                window.close();
        }

        window.clear();
        window.draw(cursor);
        window.draw(soul_sprite);
        window.display();
    }
}
