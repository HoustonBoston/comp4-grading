// Copyright 2024 Dr. Daly

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE Sokoban Tests

#include <fstream>
#include <iostream>
#include <string>
#include <sstream>

#include <SFML/Graphics.hpp>
#include <boost/test/included/unit_test.hpp>

#include "Sokoban.hpp"

using std::stringstream;
using std::string;
using std::ifstream;

using SB::Sokoban;
using SB::Direction;

const SB::Direction Up = SB::Direction::Up;
const SB::Direction Down = SB::Direction::Down;
const SB::Direction Left = SB::Direction::Left;
const SB::Direction Right = SB::Direction::Right;

namespace sf {
std::ostream& operator<<(std::ostream& out, const sf::Vector2u& pt) {
    out << "(" << pt.x << "," << pt.y << ")";
    return out;
}
bool operator==(const sf::Vector2u lhs, const sf::Vector2u& rhs) {
    return lhs.x == rhs.x && lhs.y == rhs.y;
}
}

void testCommands(
        const std::string& filename,
        const std::vector<Direction>& commands,
        sf::Vector2u pos,
        bool winAtEnd = true) {
    Sokoban game;
    std::ifstream file(filename);
    if (file.fail()) BOOST_FAIL("Problem loading file");
    file >> game;
    for (Direction c : commands) {
        BOOST_REQUIRE(!game.isWon());
        BOOST_REQUIRE_NO_THROW(game.movePlayer(c));
    }
    BOOST_REQUIRE_EQUAL(game.playerLoc(), pos);
    BOOST_REQUIRE_EQUAL(game.isWon(), winAtEnd);
}

void testPos(
        const std::string& filename,
        const std::vector<Direction>& commands,
        sf::Vector2u pos) {
    Sokoban game;
    std::ifstream file(filename);
    if (file.fail()) BOOST_FAIL("Problem loading file");
    file >> game;
    for (Direction c : commands) {
        BOOST_REQUIRE(!game.isWon());
        BOOST_REQUIRE_NO_THROW(game.movePlayer(c));
    }
    BOOST_REQUIRE_EQUAL(game.playerLoc(), pos);
}

BOOST_AUTO_TEST_CASE(TestReadPos1) {
    Sokoban sb;
    ifstream level("sokoban/level1.lvl");
    level >> sb;
    sf::Vector2u pos = {3, 6};
    BOOST_REQUIRE_EQUAL(sb.playerLoc(), pos);
}

BOOST_AUTO_TEST_CASE(TestReadPos2) {
    Sokoban sb;
    ifstream level("sokoban/level4.lvl");
    level >> sb;
    sf::Vector2u pos = {6, 1};
    BOOST_REQUIRE_EQUAL(sb.playerLoc(), pos);
}

BOOST_AUTO_TEST_CASE(TestReadSquare) {
    Sokoban sb;
    ifstream level("sokoban/level1.lvl");
    level >> sb;
    BOOST_CHECK_EQUAL(sb.height(), 10);
    BOOST_CHECK_EQUAL(sb.width(), 10);
}

BOOST_AUTO_TEST_CASE(TestReadWide) {
    Sokoban sb;
    ifstream level("sokoban/level2.lvl");
    level >> sb;
    BOOST_CHECK_EQUAL(sb.height(), 10);
    BOOST_CHECK_EQUAL(sb.width(), 12);
}

BOOST_AUTO_TEST_CASE(TestReadTall) {
    Sokoban sb;
    ifstream level("sokoban/level3.lvl");
    level >> sb;
    BOOST_CHECK_EQUAL(sb.height(), 12);
    BOOST_CHECK_EQUAL(sb.width(), 10);
}

BOOST_AUTO_TEST_CASE(TestReqMethods) {
    Sokoban sb;
    ifstream level("sokoban/level1.lvl");
    level >> sb;
    BOOST_REQUIRE_NO_THROW(sb.movePlayer(Direction::Up));
    BOOST_REQUIRE_NO_THROW(sb.movePlayer(Direction::Right));
    BOOST_REQUIRE_NO_THROW(sb.movePlayer(Direction::Left));
    BOOST_REQUIRE_NO_THROW(sb.movePlayer(Direction::Down));
    BOOST_REQUIRE_NO_THROW(sb.isWon());
}

// Autowin

BOOST_AUTO_TEST_CASE(TestAutowin) {
    std::vector<Direction> commands;
    testCommands("sokoban/autowin.lvl", commands, {2, 2});
}

BOOST_AUTO_TEST_CASE(TestAutowinBoxes) {
    std::vector<Direction> commands;
    testCommands("sokoban/autowin2.lvl", commands, {2, 2});
}

// Positions

BOOST_AUTO_TEST_CASE(TestMoveLeft) {
    std::vector<Direction> commands = { Left };
    testPos("sokoban/pushleft.lvl", commands, {1, 2});
}

BOOST_AUTO_TEST_CASE(TestMoveRight) {
    std::vector<Direction> commands = { Right };
    testPos("sokoban/pushright.lvl", commands, {3, 2});
}

BOOST_AUTO_TEST_CASE(TestMoveUp) {
    std::vector<Direction> commands = { Up };
    testPos("sokoban/pushup.lvl", commands, {2, 1});
}

BOOST_AUTO_TEST_CASE(TestMoveDown) {
    std::vector<Direction> commands = { Down };
    testPos("sokoban/pushdown.lvl", commands, {2, 3});
}

// Position Path

BOOST_AUTO_TEST_CASE(TestPathPos1) {
    std::vector<Direction> commands = { Up, Left, Down, Right, Down, Left, Down, Left, Up };
    testPos("sokoban/pushleft.lvl", commands, {0, 3});
}

BOOST_AUTO_TEST_CASE(TestPathPos2) {
    std::vector<Direction> commands = { Down, Right, Up, Left, Up, Right, Up, Right, Down };
    testPos("sokoban/pushright.lvl", commands, {4, 1});
}

// Position Collision

BOOST_AUTO_TEST_CASE(TestLevel1BlockPos) {
    std::vector<Direction> commands = { Right, Up, Right, Up, Right, Right, Up, Right, Down,
        Up, Up, Left, Left, Left, Up, Left, Down, Up };
    testPos("sokoban/level1.lvl", commands, {5, 2});
}

BOOST_AUTO_TEST_CASE(TestLevel3BlockPos) {
    std::vector<Direction> commands = { Right, Up, Right, Up, Right, Right, Up, Right, Right, Down,
        Up, Right, Up, Left, Left, Left, Up, Up, Right, Up, Left, Up, Left, Down, Up };
    testPos("sokoban/level3.lvl", commands, {5, 2});
}

BOOST_AUTO_TEST_CASE(TestLevel2BlockPos) {
    std::vector<Direction> commands = { Up, Down, Right, Up, Right, Up, Left, Up, Left,
        Down, Down, Down, Left, Down, Right,
        Up, Up, Up, Up, Up, Left, Down, Right, Down, Left, Left, Left, Left,
        Right, Right, Right, Down, Down, Down, Left, Down, Right, Right,
        Down, Right, Up, Up, Up, Up, Up, Up, Right, Up, Left, Left };
    testPos("sokoban/level2.lvl", commands, {8, 1});
}

// Win / No Collision

BOOST_AUTO_TEST_CASE(TestPushLeft) {
    std::vector<Direction> commands = { Left };
    testCommands("sokoban/pushleft.lvl", commands, {1, 2});
}

BOOST_AUTO_TEST_CASE(TestPushRight) {
    std::vector<Direction> commands = { Right };
    testCommands("sokoban/pushright.lvl", commands, {3, 2});
}

BOOST_AUTO_TEST_CASE(TestPushUp) {
    std::vector<Direction> commands = { Up };
    testCommands("sokoban/pushup.lvl", commands, {2, 1});
}

BOOST_AUTO_TEST_CASE(TestPushDown) {
    std::vector<Direction> commands = { Down };
    testCommands("sokoban/pushdown.lvl", commands, {2, 3});
}

BOOST_AUTO_TEST_CASE(TestPath1) {
    std::vector<Direction> commands = { Up, Left, Down, Right, Down, Left, Down, Left, Up };
    testCommands("sokoban/pushleft.lvl", commands, {0, 3});
}

BOOST_AUTO_TEST_CASE(TestPath2) {
    std::vector<Direction> commands = { Down, Right, Up, Left, Up, Right, Up, Right, Down };
    testCommands("sokoban/pushright.lvl", commands, {4, 1});
}

BOOST_AUTO_TEST_CASE(TestLevel1) {
    std::vector<Direction> commands = { Right, Right, Right, Right, Up, Right, Down,
        Up, Up, Up, Left, Left, Left, Up };
    testCommands("sokoban/level1.lvl", commands, {5, 2});
}

BOOST_AUTO_TEST_CASE(TestLevel3) {
    std::vector<Direction> commands = { Right, Right, Right, Right, Up, Right, Down,
        Up, Up, Up, Up, Up, Left, Left, Left, Up };
    testCommands("sokoban/level3.lvl", commands, {5, 2});
}

BOOST_AUTO_TEST_CASE(TestSwap) {
    std::vector<Direction> commands = { Up, Down, Right, Right, Up, Left };
    testCommands("sokoban/swapoff.lvl", commands, {3, 1});
}

// Win / Collisions

BOOST_AUTO_TEST_CASE(TestLevel1Block) {
    std::vector<Direction> commands = { Right, Up, Right, Up, Right, Right, Up, Right, Down,
        Up, Up, Left, Left, Left, Up, Left, Down, Up };
    testCommands("sokoban/level1.lvl", commands, {5, 2});
}

BOOST_AUTO_TEST_CASE(TestLevel3Block) {
    std::vector<Direction> commands = { Right, Up, Right, Up, Right, Right, Up, Right, Right, Down,
        Up, Right, Up, Left, Left, Left, Up, Up, Right, Up, Left, Up, Left, Down, Up };
    testCommands("sokoban/level3.lvl", commands, {5, 2});
}

BOOST_AUTO_TEST_CASE(TestLevel2Block) {
    std::vector<Direction> commands = { Up, Down, Right, Up, Right, Up, Left, Up, Left,
        Down, Down, Down, Left, Down, Right,
        Up, Up, Up, Up, Up, Left, Down, Right, Down, Left, Left, Left, Left,
        Right, Right, Right, Down, Down, Down, Left, Down, Right, Right,
        Down, Right, Up, Up, Up, Up, Up, Up, Right, Up, Left, Left };
    testCommands("sokoban/level2.lvl", commands, {8, 1});
}

// Boundaries

BOOST_AUTO_TEST_CASE(TestOffDown) {
    std::vector<Direction> commands = { Down, Down, Down, Up, Up, Up };
    testCommands("sokoban/pushup.lvl", commands, {2, 1});
}

BOOST_AUTO_TEST_CASE(TestOffLeft) {
    std::vector<Direction> commands = { Right, Right, Right, Left, Left, Left };
    testCommands("sokoban/pushleft.lvl", commands, {1, 2});
}

BOOST_AUTO_TEST_CASE(TestOffRight) {
    std::vector<Direction> commands = { Left, Left, Left, Right, Right, Right };
    testCommands("sokoban/pushright.lvl", commands, {3, 2});
}

BOOST_AUTO_TEST_CASE(TestOffUp) {
    std::vector<Direction> commands = { Up, Up, Up, Down, Down, Down };
    testCommands("sokoban/pushdown.lvl", commands, {2, 3});
}

// Uneven numbers

BOOST_AUTO_TEST_CASE(TestLevelMoreBoxes) {
    std::vector<Direction> commands =
        { Right, Right, Right, Right, Up, Up, Up, Up, Left, Up, Right };
    testCommands("sokoban/level5.lvl", commands, {5, 1});
}

BOOST_AUTO_TEST_CASE(TestLevelMoreStorage) {
    std::vector<Direction> commands = { Up, Right, Right, Right, Right, Up, Right, Down,
        Up, Up, Up, Left, Left, Left, Left, Down, Left, Up };
    testCommands("sokoban/level6.lvl", commands, {1, 2});
}

