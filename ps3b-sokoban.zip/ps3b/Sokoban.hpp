// Copyright 2024 Jaeda
#pragma once

#include <iostream>
#include <vector>

#include <SFML/Graphics.hpp>

namespace SB {
enum class Direction {
    Up, Down, Left, Right
};

class GameState {
 public:
    Direction facing;
    sf::Vector2u playerPos;
    std::vector<sf::Vector2u> boxes;
};

class Sokoban: public sf::Drawable {
 public:
    static const unsigned int TILE_SIZE = 64;

    Sokoban();

    sf::Vector2u size() const { return {width(), height()}; }
    unsigned int width() const { return _width; }
    unsigned int height() const { return _height; }

    sf::Vector2u windowSize() const { return size() * TILE_SIZE; }

    sf::Vector2u playerLoc() const { return _states.back().playerPos; }

    bool isWon() const;

    void movePlayer(Direction dir);
    void reset();

    void undo();
    void redo();

 protected:
    void draw(sf::RenderTarget& window, sf::RenderStates states) const override;

 private:
    std::vector<char> _tiles;
    size_t _width;
    size_t _height;
    // sf::Vector2u _player;
    // std::vector<sf::Vector2u> _boxes;
    std::vector<GameState> _states;
    std::vector<GameState> _redos;
    std::vector<sf::Vector2u> _targets;

    // Direction _facing;

    sf::Texture _wallTex;
    sf::Texture _floorTex;
    sf::Texture _targetTex;
    sf::Texture _boxTex;

    sf::Texture _faceDown;
    sf::Texture _faceUp;
    sf::Texture _faceLeft;
    sf::Texture _faceRight;

    char at(size_t x, size_t y) const { return _tiles[y * _width + x]; }
    char at(sf::Vector2u pt) const { return at(pt.x, pt.y); }

    friend std::ostream& operator<<(std::ostream& os, const Sokoban& game);
    friend std::istream& operator>>(std::istream& is, Sokoban& game);
};

std::ostream& operator<<(std::ostream& os, const Sokoban& game);
std::istream& operator>>(std::istream& is, Sokoban& game);

}  // namespace SB
