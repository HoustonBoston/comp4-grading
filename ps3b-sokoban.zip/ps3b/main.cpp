// Copyright 2024 Jaeda
#include <fstream>

#include <SFML/Graphics.hpp>

#include "Sokoban.hpp"

using sf::Keyboard::Key;

int main(int argc, const char* argv[]) {
    SB::Sokoban game;
    std::ifstream file(argv[1]);
    file >> game;

    sf::RenderWindow window(sf::VideoMode(game.windowSize()), "SFML works!");

    sf::Font font("Roboto-Regular.ttf");
    sf::Text text(font, "You win!");
    text.setFillColor(sf::Color::Yellow);
    text.setPosition({
        (window.getSize().x - text.getLocalBounds().size.x) / 2,
        (window.getSize().y - text.getLocalBounds().size.y) / 2
    });

    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
            } else if (event->is<sf::Event::KeyPressed>()) {
                auto keyevent = event->getIf<sf::Event::KeyPressed>();
                switch (keyevent->code) {
                 case Key::W:
                 case Key::Up:
                    game.movePlayer(SB::Direction::Up);
                    break;
                 case Key::S:
                 case Key::Down:
                    game.movePlayer(SB::Direction::Down);
                    break;
                 case Key::A:
                 case Key::Left:
                    game.movePlayer(SB::Direction::Left);
                    break;
                 case Key::D:
                 case Key::Right:
                    game.movePlayer(SB::Direction::Right);
                    break;
                 case Key::R:
                    game.reset();
                    break;
                 default: break;
                }
            }
        }

        window.clear();
        window.draw(game);
        if (game.isWon()) {
            window.draw(text);
        }
        window.display();
    }

    return 0;
}
