// Copyright 2024 Jaeda
#include "Sokoban.hpp"

#include <algorithm>

using std::find;

namespace SB {
Sokoban::Sokoban():
    _width(0),
    _height(0),
    _wallTex("sokoban/block_06.png"),
    _floorTex("sokoban/ground_01.png"),
    _targetTex("sokoban/environment_03.png"),
    _boxTex("sokoban/crate_03.png"),
    _faceDown("sokoban/player_05.png"),
    _faceUp("sokoban/player_08.png"),
    _faceLeft("sokoban/player_20.png"),
    _faceRight("sokoban/player_17.png")
    {}

bool Sokoban::isWon() const {
    const auto& boxes = _states.back().boxes;
    return std::all_of(boxes.begin(), boxes.end(),
        [this](auto box) {
            return find(_targets.begin(), _targets.end(), box) != _targets.end();
        }) || std::all_of(_targets.begin(), _targets.end(),
        [boxes](auto tgt) {
            return find(boxes.begin(), boxes.end(), tgt) != boxes.end();
        });
}

void Sokoban::movePlayer(Direction dir) {
    if (isWon()) return;
    GameState state = _states.back();
    state.facing = dir;
    sf::Vector2u delta;
    switch (dir) {
        case Direction::Up: delta.y = -1; break;
        case Direction::Left: delta.x = -1; break;
        case Direction::Down: delta.y = +1; break;
        case Direction::Right: delta.x = +1; break;
    }
    auto next = playerLoc() + delta;
    if (next.x >= _width || next.y >= _height) return;
    if (at(next) == '#') return;
    auto box = std::find(state.boxes.begin(), state.boxes.end(), next);
    if (box != state.boxes.end()) {
        auto past = next + delta;
        if (past.x >= _width || past.y >= _height) return;
        if (at(past) == '#') return;
        if (std::find(state.boxes.begin(), state.boxes.end(), past) != state.boxes.end()) return;
        *box += delta;
    }
    state.playerPos = next;
    _states.push_back(state);
    _redos.clear();
}

void Sokoban::reset() {
    _redos.clear();
    _states.clear();
    _states.push_back(GameState());
    _targets.clear();
    for (size_t y = 0; y < height(); y++) {
        for (size_t x = 0; x < width(); x++) {
            switch (at(x, y)) {
             case '@': _states.back().playerPos = sf::Vector2u(x, y); break;
             case 'A': _states.back().boxes.push_back(sf::Vector2u(x, y)); break;
             case 'a': _targets.push_back(sf::Vector2u(x, y)); break;
             case '1':
                _states.back().boxes.push_back(sf::Vector2u(x, y));
                _targets.push_back(sf::Vector2u(x, y));
                break;
             default:
                break;
            }
        }
    }
    _states.back().facing = Direction::Down;
}

void Sokoban::draw(sf::RenderTarget& window, sf::RenderStates states) const {
    for (size_t y = 0; y < height(); y++) {
        for (size_t x = 0; x < width(); x++) {
            sf::Sprite sprite(_floorTex);
            sprite.setPosition(sf::Vector2f(x * TILE_SIZE, y * TILE_SIZE));
            window.draw(sprite, states);
            if (at(x, y) == '#') {
                sprite.setTexture(_wallTex);
                window.draw(sprite, states);
            }
        }
    }
    for (auto pos : _states.back().boxes) {
        sf::Sprite sprite(_boxTex);
        sprite.setPosition(sf::Vector2f(pos.x * TILE_SIZE, pos.y * TILE_SIZE));
        window.draw(sprite, states);
    }
    for (auto pos : _targets) {
        sf::Sprite sprite(_targetTex);
        sprite.setPosition(sf::Vector2f(pos.x * TILE_SIZE, pos.y * TILE_SIZE));
        window.draw(sprite, states);
    }
    const sf::Texture* tex;
    switch (_states.back().facing) {
     case Direction::Down: tex = &_faceDown; break;
     case Direction::Up: tex = &_faceUp; break;
     case Direction::Left: tex = &_faceLeft; break;
     case Direction::Right: tex = &_faceRight; break;
    }

    sf::Sprite player(*tex);
    auto pos = _states.back().playerPos * TILE_SIZE;
    player.setPosition((sf::Vector2f)pos);
    window.draw(player, states);
}

std::ostream& operator<<(std::ostream& os, const Sokoban& game) {
    os << game.height() << " " << game.width() << std::endl;
    for (size_t y = 0; y < game.height(); y++) {
        for (size_t x = 0; x < game.width(); x++) {
            sf::Vector2u pos(x, y);
            if (game.at(x, y) == '#') {
                os << '#';
            } else if (game.playerLoc() == pos) {
                os << '@';
            } else if (find(
                    game._states.back().boxes.begin(), 
                    game._states.back().boxes.end(), pos) != game._states.back().boxes.end()) {
                if (find(game._targets.begin(), game._targets.end(), pos) != game._targets.end()) {
                    os << '1';
                } else {
                    os << 'A';
                }
            } else if (
                    find(game._targets.begin(), game._targets.end(), pos) != game._targets.end()) {
                os << 'a';
            } else {
                os << '.';
            }
        }
        os << std::endl;
    }
    return os;
}

std::istream& operator>>(std::istream& is, Sokoban& game) {
    is >> game._height >> game._width;
    game._tiles = {};
    for (size_t y = 0; y < game.height(); y++) {
        std::string line;
        is >> line;
        for (size_t x = 0; x < game.width(); x++) {
            game._tiles.push_back(line[x]);
        }
    }
    game.reset();
    return is;
}

void Sokoban::undo() {
    if (_states.size() > 1) {
        _redos.push_back(_states.back());
        _states.pop_back();
    }
}

void Sokoban::redo() {
    if (!_redos.empty()) {
        _states.push_back(_redos.back());
        _redos.pop_back();
    }
}
}  // namespace SB
